DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',    
    'password': 'Foxy399.',
    'database': 'used_cars_db'
}

DATA_PATHS = {
    'kaggle': 'data/raw/used_cars.csv',  # Downloaded from Kaggle
    'output': 'data/processed/cleaned_cars.csv'
}